package com.buenosautos.buenosautosagendamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuenosautosagendamentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BuenosautosagendamentoApplication.class, args);
	}

}
