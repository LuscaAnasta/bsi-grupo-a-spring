package com.buenosautos.buenosautosagendamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuenosautosagendamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
